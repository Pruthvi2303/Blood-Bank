from flask import Flask, render_template, request, redirect, url_for
import os
import pyodbc

app = Flask(__name__)

# Database connection setup
def get_db_connection():
    db_path = os.path.join(os.getcwd(), 'Database.accdb')  # Full path
    conn = pyodbc.connect(f'DRIVER={{Microsoft Access Driver (*.mdb, *.accdb)}};DBQ={db_path}')
    return conn

# Home route
@app.route('/')
def home():
    return render_template('home.html')

# Admin Dashboard Route
@app.route('/admin_dashboard')
def admin_dashboard():
    conn = get_db_connection()
    cursor = conn.cursor()

    # Fetching all donors
    cursor.execute("SELECT * FROM Donors")
    donors = cursor.fetchall()

    # Fetching all recipients
    cursor.execute("SELECT * FROM Recipients")
    recipients = cursor.fetchall()

    return render_template('admin_dashboard.html', donors=donors, recipients=recipients)

# Admin Login Route
@app.route('/admin_login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = get_db_connection()
        cursor = conn.cursor()

        # Query the Admins table for credentials
        cursor.execute("SELECT * FROM Admins WHERE Username = ? AND PasswordHash = ?", (username, password))
        admin = cursor.fetchone()

        if admin:
            # Redirect to admin dashboard after successful login
            return redirect(url_for('admin_dashboard'))
        else:
            # Return an error if credentials are incorrect
           return render_template('admin_login.html', error="Invalid username or password. Please try again.")

    return render_template('admin_login.html')


# Donor Registration Route
@app.route('/donor_register', methods=['GET', 'POST'])
def donor_register():
    if request.method == 'POST':
        # Save the donor registration data to the database
        name = request.form['name']
        blood_group = request.form['blood_group']
        contact = request.form['contact']

        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute("INSERT INTO Donors (Name, BloodGroup, Contact) VALUES (?, ?, ?)",
                       (name, blood_group, contact))
        conn.commit()

        return redirect(url_for('home'))

    return render_template('donor_register.html')

# Recipient Registration Route
@app.route('/recipient_register', methods=['GET', 'POST'])
def recipient_register():
    if request.method == 'POST':
        # Save the recipient registration data to the database
        name = request.form['name']
        blood_group_needed = request.form['blood_group_needed']
        hospital = request.form['hospital']

        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute("INSERT INTO Recipients (Name, blood_group_needed, Hospital) VALUES (?, ?, ?)",
                       (name, blood_group_needed, hospital))
        conn.commit()

        return redirect(url_for('home'))

    return render_template('recipient_register.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
